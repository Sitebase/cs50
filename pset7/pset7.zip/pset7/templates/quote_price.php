<p>A share of <?php echo $name ?>(<?php echo strtoupper($symbol) ?>) costs <strong><?php echo $price ?></strong>.
